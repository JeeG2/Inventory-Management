package lab3;

public class Implementation {
	public static void main(String agrs[]) {
		Exercise1 e= new Exercise1();
		int []arr={2,534,33,1345,5324,5321};
		int a=e.getSecondSmallest(arr);
		System.out.println(a);
		
	}
}
