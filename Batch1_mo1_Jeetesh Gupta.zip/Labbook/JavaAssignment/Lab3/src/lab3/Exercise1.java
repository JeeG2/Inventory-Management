package lab3;

import java.util.Arrays;

public class Exercise1 {

	public int getSecondSmallest(int [] arr) {
		
		Arrays.parallelSort(arr);
		int min = arr[0];
		for (int val : arr) {
			if (val >min) {
				return val;
			}
		}
		return arr[1];
	}
}
