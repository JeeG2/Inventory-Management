package lab3;

import java.util.Arrays;

public class Exercise2 {

	public String[] sortString(String str[]) {
		Arrays.parallelSort(str);
		if (str.length%2 ==0) {
			
			for(int i=0; i<str.length/2;i++) {
				str[i]=str[i].toUpperCase();
			}
			for(int i=(str.length/2);i<str.length;i++) {
				str[i]=str[i].toLowerCase();
			}
		}
		else {
			
			for(int i=0;i<=str.length/2;i++) {
				str[i]=str[i].toUpperCase();
			}
			for(int i=(str.length/2);i<str.length;i++) {
				str[i]=str[i].toLowerCase();
			}
		}
		return str;
	}
	
}
