package lab4;

public class Exercise1 {
	public int sumOfCubes(int n) {
		int sum=0;
		int m=0;
		while(n>0) {
			m=(n%10);
			sum+= (m*m*m);
			n/=10;
		}
		return sum;
	}

}
