package lab2;

public class Video extends MediaItem {

	private String director;
	private String genre;
	private int releasedYear;
	
	/**
	 * @param identifactionNo
	 * @param title
	 * @param numberOfCopies
	 * @param runTime
	 * @param director
	 * @param genre
	 * @param releasedYear
	 */
	public Video(int identifactionNo, String title, int numberOfCopies, int runTime, String director, String genre,
			int releasedYear) {
		super(identifactionNo, title, numberOfCopies, runTime);
		this.director = director;
		this.genre = genre;
		this.releasedYear = releasedYear;
	}

	/**
	 * @return the director
	 */
	public String getDirector() {
		return director;
	}

	/**
	 * @param director the director to set
	 */
	public void setDirector(String director) {
		this.director = director;
	}

	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * @return the releasedYear
	 */
	public int getReleasedYear() {
		return releasedYear;
	}

	/**
	 * @param releasedYear the releasedYear to set
	 */
	public void setReleasedYear(int releasedYear) {
		this.releasedYear = releasedYear;
	}

	@Override
	public String toString() {
		return "Video [director=" + director + ", genre=" + genre + ", releasedYear=" + releasedYear + "]";
	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}
	
	
}
