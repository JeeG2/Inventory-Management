package lab2;

public abstract class WrittenItem extends Item{

	private String author ;
	
	public WrittenItem(int identifactionNo, String title, int numberOfCopies, String author) {
		
		super(identifactionNo, title, numberOfCopies);
		// TODO Auto-generated constructor stub
		this.author=author;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {

		this.author = author;
	}
	

	@Override
	public String toString() {
		return "WrittenItem [author=" + author + "]";
	}
	

	
}
