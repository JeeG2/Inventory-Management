package lab2;

public abstract class Item {

	private int identifactionNo;
	private String title;
	private int numberOfCopies;
	
	/**
	 * @param identifactionNo
	 * @param title
	 * @param numberOfCopies
	 */
	public Item(int identifactionNo, String title, int numberOfCopies) {
		super();
		this.identifactionNo = identifactionNo;
		this.title = title;
		this.numberOfCopies = numberOfCopies;
	}
	
	/**
	 * @return the identifactionNo
	 */
	public int getIdentifactionNo() {
		return identifactionNo;
	}
	
	
	/**
	 * @param identifactionNo the identifactionNo to set
	 */
	public void setIdentifactionNo(int identifactionNo) {
		this.identifactionNo = identifactionNo;
	}
	
	
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	
	
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	/**
	 * @return the numberOfCopies
	 */
	public int getNumberOfCopies() {
		return numberOfCopies;
	}
	
	
	/**
	 * @param numberOfCopies the numberOfCopies to set
	 */
	public void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}
	
	
	@Override
	public String toString() {

		return "Item [identifactionNo=" + identifactionNo + ", title=" + title + ", numberOfCopies=" + numberOfCopies
				+ "]";
	}
	
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (this == obj ) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Item sample = (Item) obj;
        return identifactionNo == sample.identifactionNo &&
                numberOfCopies == sample.numberOfCopies &&
                title.equals(sample.title);
	}

	public abstract void checkIn();
	public abstract void checkOut();
	public abstract void print();
	public abstract void addItem();
	
	
	
}
