package lab10;

public class Exercise3 {
	@FunctionalInterface
	interface Accept{

		public boolean check(String usernam,String password);
	}

	public static void main(String[]args) {
		String username="jigsbij";
		String password="@244234hffj";
		Accept a=(s1,s2)->{
			if(s1.equals("jigsbij") && s2.equals("@244234hffj"));
			return true;
		};
		System.out.println(a.check(username,password));
	}
}
