package lab8;

public class Lab8Ex2 {

	public static void main(String[]args) {
       Exercise2 t=new Exercise2();
       Thread tr=new Thread(t);
       tr.start();
	}
}