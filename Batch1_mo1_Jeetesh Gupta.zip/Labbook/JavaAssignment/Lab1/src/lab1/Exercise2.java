package lab1;

public class Exercise2 {
	
	
	//Calculate the difference 
	
	public int calculateDifference(int n)
	{
		int sum1=0 , sum2=0;
		
		for(int i=1;i<=n;i++)
		{
			sum1=sum1+i*i;
			sum2=sum2+i;
		}
		
		sum2= sum2 * sum2;
		return Math.abs(sum2-sum1);
		
	}

}