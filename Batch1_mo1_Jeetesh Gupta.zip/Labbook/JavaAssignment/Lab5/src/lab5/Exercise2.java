package lab5;

public class Exercise2 {
	// Implenetion Fibonacci recursively
	public int recursiveFibonacci(int a) {
		if ((a==1) || (a==2)) {
			return 1;
		}
		return recursiveFibonacci(a-2) + recursiveFibonacci(a-1); 
	}
	
	// Implenetion Fibonacci Non_recursive
	public int nonRecursiveFibonacci(int a) {
		if ((a==1) || (a==2)) {
			return 1;
		}
		int value=0;
		int p = 1;
		int q = 1;
		for(int i=3; i<=a; i++) {
			value = p+q;
			p=q;
			q=value;
		}
		return value;
	}
}
