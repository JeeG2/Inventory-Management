package lab5;

import java.util.Scanner;

public class Exercise1 {

	
	public void trafficLight() throws  Exception{
		System.out.println("Enter the option \n 1- RED LIGHT. \n 2- YELLOW LIGHT \n 3- GREEN LIGHT \n");
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		scan.close();
		
		switch (a) {
		case 1:
			System.out.println("STOP");
			break;
		case 2:
			System.out.println("READY");
			break;
		case 3:
			System.out.println("GO");
		default:
			System.out.println("INVALID OPTION");
			throw new Exception("INVALID OPTION");
		}
		
	}
}
