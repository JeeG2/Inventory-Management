package lab5;

import java.util.Scanner;

public class Exercise3 {

	public void printPrime() {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int size =  scan.nextInt() +1;scan.close();
		boolean [] arr = new boolean[size];
		for(int i=0; i<arr.length;i++) {
			arr[i] = true;
		}
		for( int i =2 ; i< size;i++) {
			if (arr[i]) {
				for (int j=(i+i); j<size;j+=i) {
					arr[j]=false;
				}
			}
			
		}
		
		for( int i=2;i<size;i++) {
			if (arr[i]) {
				System.out.print(i + " ");
			}
		}
		
		
		
	}
}
