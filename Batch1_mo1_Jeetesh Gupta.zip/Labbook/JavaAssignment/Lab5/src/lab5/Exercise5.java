package lab5;

@SuppressWarnings("serial")
class ageException extends RuntimeException{
	/**
	 * 
	 */

	public ageException(String msg) {
		super(msg);
	}
}
public class Exercise5 {

	public boolean validateAge(int age) throws ageException {
		
		if (age<16) {
			throw new ageException("Age should be above 15");
		}
		else
		{
			return true;
		}
	}
}
