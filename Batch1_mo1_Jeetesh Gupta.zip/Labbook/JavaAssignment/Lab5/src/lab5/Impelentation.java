package lab5;

public class Impelentation {

	public static void main(String[] args) {
		// TODO Auto-generated me5thod stub
		Exercise4 e= new Exercise4();
		if(e.isNameValid("giygi", ""))
			System.out.println("Valid full name");
	}

}
